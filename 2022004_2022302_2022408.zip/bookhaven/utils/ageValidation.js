//write function to check whether the person's age is above 18 or not

